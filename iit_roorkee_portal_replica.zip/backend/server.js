const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const users = [{ roll: '12345', password: 'iitroorkee' }];

app.post('/api/login', (req, res) => {
  const { roll, password } = req.body;
  const user = users.find(u => u.roll === roll && u.password === password);
  if (user) res.status(200).send('Login successful');
  else res.status(401).send('Invalid credentials');
});

app.listen(5000, () => console.log('Server running on port 5000'));