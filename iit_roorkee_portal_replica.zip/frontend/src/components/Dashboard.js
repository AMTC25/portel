import React from 'react';

function Dashboard() {
  return (
    <div className="dashboard">
      <h2>Welcome to IIT Roorkee Portal</h2>
      <p>This is a replica student dashboard.</p>
    </div>
  );
}

export default Dashboard;